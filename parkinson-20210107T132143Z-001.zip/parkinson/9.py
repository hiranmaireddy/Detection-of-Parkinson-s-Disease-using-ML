# -*- coding: utf-8 -*-
"""
Created on Tue Dec 29 14:09:52 2020

@author: nithya
"""

features = quantify_image(image)
preds = model.predict([features])
label = le.inverse_transform(preds)[0]
color = (0, 255, 0) if label == "healthy" else (0, 0, 255)
cv2.putText(output, label, (3, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
images.append(output)