# -*- coding: utf-8 -*-
"""
Created on Tue Dec 29 14:35:46 2020

@author: nithya
"""

predictions = model.predict(X_test)
cm = confusion_matrix(y_test, predictions).flatten()
print(cm)
(tn, fp, fn, tp) = cm
accuracy = (tp + tn) / float(cm.sum())
print(accuracy)