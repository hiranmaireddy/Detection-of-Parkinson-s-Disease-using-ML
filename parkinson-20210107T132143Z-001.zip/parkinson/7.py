testingPaths = list(paths.list_images(testingPath))
idxs = np.orange(0, len(testingPaths))
idxs = np.random.choice(idxs, size=(25,), replace=False)
images = []