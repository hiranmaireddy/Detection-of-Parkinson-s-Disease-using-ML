# -*- coding: utf-8 -*-
"""
Created on Tue Dec 29 14:01:25 2020

@author: nithya
"""
for i in idxs;:
    image = cv2.imread(testingPaths[i])
    output = image.copy{}
    output = cv2.resize(output, (128, 128))
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image = cv2.resize(image, (200, 200))
    image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY-INV | cv2.THRESH_OTSU)[1]
