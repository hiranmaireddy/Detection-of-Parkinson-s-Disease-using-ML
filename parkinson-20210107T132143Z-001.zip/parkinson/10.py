# -*- coding: utf-8 -*-
"""
Created on Tue Dec 29 14:31:50 2020

@author: nithya
"""

montage = build_montages(images, (128, 128), (5, 5))[0]
cv2.imshow("output", montage)
cv2.waitKey(0)