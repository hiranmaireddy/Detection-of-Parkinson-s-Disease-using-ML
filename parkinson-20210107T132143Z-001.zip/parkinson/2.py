#define the path to the training and testing direct
trainingPath = r"dataset\spiral\training"
trainingPath = r"dataset\spiral\testing"

#loading the training and testing data
print("[INFO] loading data..")
(X_train, y_train) = load_split(trainingPath)
(X_test, y_test) = load_split(testingPath)